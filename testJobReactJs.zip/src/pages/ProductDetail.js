import { Box, Grid, ListItem, Item, Typography } from "@mui/material";
import React from "react"
import LeftSideBar from "../components/LeftSidebar";

const ProductDetail = () => {
    return(
        <Box sx={{flex:1, display:'flex'}}>
            <Grid container rowSpacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
                <Grid item xs={3}>
                    <LeftSideBar />
                </Grid>
                <Grid item xs={6}>
                    <ListItem>2</ListItem>
                </Grid>
                <Grid item xs={3}>
                    <ListItem>3</ListItem>
                </Grid> 
            </Grid>
        </Box>
    )
}

export default ProductDetail;